Cell filter
===========

An extension that allows you to filter cells by tags. Keywords entered into the search bar separated by spaces joins them with logical AND.
