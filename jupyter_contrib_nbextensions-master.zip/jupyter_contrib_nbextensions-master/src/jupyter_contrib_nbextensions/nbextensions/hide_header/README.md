Hide Header
===========

Add keyboard shortcut to toggle the whole header, menubar and toolbar visibility.
