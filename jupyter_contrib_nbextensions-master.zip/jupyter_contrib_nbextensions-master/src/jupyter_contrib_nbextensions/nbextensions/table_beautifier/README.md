Table Beautifier
================

Add bootstrap styling to tables in markdown cells and in html/md output.
