Datestamper
===========

Adds a toolbar button which pastes the current time & date into the current cell:

![](icon.png)
