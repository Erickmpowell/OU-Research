Help menu entry
===============

The `contrib_nbextensions_help_item` is a tiny nbextension that just adds an
item to the notebook's help menu, pointing to the docs at readthedocs:
[jupyter_contrib_nbextensions.readthedocs.io](https://jupyter_contrib_nbextensions.readthedocs.io)
