QT Console
==========

Launch a QTConsole attached to the running kernel
