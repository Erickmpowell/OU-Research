# Split Cells

Enter command mode (esc), use shift-s to toggle the current cell to either a split cell or full width.
