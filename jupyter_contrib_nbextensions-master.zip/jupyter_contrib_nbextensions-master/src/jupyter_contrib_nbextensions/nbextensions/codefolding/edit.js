define(['./main'], function (codefolding) {
    "use strict";
    return codefolding;
});
