Comment/Uncomment
=================

Adds a new configurable hotkey binding to toggle comments on/off.

Options
-------

**comment_uncomment_keybinding**: keybinding for toggling comments (default: Alt-c)

***comment_uncomment_indent***: add comment at current indent level instead of at beginning of line
