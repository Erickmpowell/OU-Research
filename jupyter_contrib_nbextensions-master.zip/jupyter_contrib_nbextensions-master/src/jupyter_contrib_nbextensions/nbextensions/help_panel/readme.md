Help Panel
===========

Installing the extension adds a new button to the toolbar:

![](icon.png)

On clicking the button, the notebook width is reduced and a side panel is displayed showing help.
The contents of the help panel are exactly the same as when going to `Keyboard Shortcuts` in the `Help` menu.

![](help_panel_ext.png)

You can drag the sidebar divider to resize it, or click the expand icon at the top left of the bar to get the help panel to expand to fill the screen:

![](help_panel_ext_fullscreen.png)
