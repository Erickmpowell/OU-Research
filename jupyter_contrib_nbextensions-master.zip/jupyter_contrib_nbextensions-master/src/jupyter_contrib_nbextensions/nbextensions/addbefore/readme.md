Addbefore
=========

This extension adds a button to add a empty cell before the currently active cell.
As was present in IPython 1.0.
It is with a circled up arrow.
The plus signed "Add Cell After button" is moved to be next to Add Cell Before,
and given matching circled down arrow icon.

The functionality of the buttons are as per in the Insert Menu,
for Insert Cell Above, and Insert Cell Below.
A empty cell is added, and it takes the cursor focus.
