Code Font Size
==============

Adds toolbar buttons to increase and decrease code's font size. This is useful, for example, when projecting the notebook.
